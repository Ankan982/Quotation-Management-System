<?php

echo "Suceessfull data insertion";


?>