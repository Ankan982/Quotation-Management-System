<?php

foreach ($_SESSION["cart_item"] as $item) {

     echo $item["part_number"]; 


}



?>