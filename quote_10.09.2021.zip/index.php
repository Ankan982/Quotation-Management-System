<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Quote</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj" crossorigin="anonymous"></script>
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">

		<div class="container-fluid">
			<a class="navbar-brand" href="#">Quotation</a>
			<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbarSupportedContent">
				<ul class="navbar-nav me-auto mb-2 mb-lg-0">
					<li class="nav-item" >
						<a class="nav-link active" aria-current="page" href="#">Home</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="#">Quote</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="import_page.php">Import</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="customer.php">Customer Info</a>
					</li>
				</div>
			</div>
		</nav>


		<div class="container mt-2 border border-primary">
			
            <form method="post" action="index.php">
			 <div class="col-auto">
						<label for="inputEmail4" class="form-label">Part Number</label>
						<input type="text" name="part_number" class="form-control" id="inputEmail4">
			 </div>

			 <div class="d-flex justify-content-center">	
			 	<div>
					<div class="form-check form-check-inline">
					  <input class="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1">
					  <label class="form-check-label" for="inlineCheckbox1">Generic</label>
					</div>
					<div class="form-check form-check-inline">
					  <input class="form-check-input" type="checkbox" id="inlineCheckbox2" value="option2">
					  <label class="form-check-label" for="inlineCheckbox2">Genuine</label>
					</div>
			    </div>
				   <div>
					<button type="submit" name="submit" class="btn btn-primary mt-2">Search</button>
			       </div>
		      </form>
		     </div>

		</div>	

		<?php


    include("database.php");

    if (isset($_POST['submit']))
	 {
      $part_number = $_POST['part_number'];

        if($part_number!="")
		{
			$query = "SELECT * FROM MKP_tbl WHERE part_number= '$part_number' ";


			$query_run = mysqli_query($conn, $query);
			$check = mysqli_num_rows($query_run) > 0;
	
			if ($check) {
			  while ($rows = mysqli_fetch_array($query_run)) {
?>
				
		

		<div class="container border border-primary mt-5">
			<div class="d-flex justify-content-center mt-3"> 
				<form class="row g-3 ">
					<div class="col-md-6">
						<label for="inputEmail4" class="form-label">Part Number</label>
						<input type="text" class="form-control" name="part_number" value="<?php echo $rows['part_number']; ?>">
					</div>
					<div class="col-12">
						<label for="inputAddress" class="form-label">Description</label>
						<input type="text" class="form-control"name="description" value="<?php echo $rows['description']; ?>">
					</div>
					<div class="col-md-6">
						<label for="inputCity" class="form-label">Weight</label>
						<input type="text" class="form-control" name="weight" value="<?php echo $rows['weight']; ?>">
					</div>
					<div class="col-md-4">
						<label for="inputCity" class="form-label">Brand</label>
						<input type="text" class="form-control"name="brand" value="<?php echo $rows['brand'];?>">
					</div>
					<div class="col-md-4">
						<label for="inputZip" class="form-label">Price</label>
						<input type="text" class="form-control" name="price" value="<?php echo $rows['price']; ?>">
					</div>
					<div class="col-md-4">
						<label for="inputPassword4" class="form-label">Quantity</label>
						<input type="text" name="quantity" class="form-control" id="inputPassword4">
					</div>
					<div class="col-12">
						<button type="submit" class="btn btn-primary mb-3">Add</button>
					</div>
				</form>
			</div>	
		</div>



	</body>
	</html>

	<?php
			  }
			} 
		else {
			echo "No data Found!!";
			}
		}
	}
?>
	
    
